<TS language="es_AR" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Hacé click para editar la dirección o etiqueta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crear una nueva dirección</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nuevo</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copiá la dirección que seleccionaste al portapapeles</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>C&amp;lose</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Borrar de la lista la dirección seleccionada</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportar los datos de la pestaña actual a un archivo</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportar</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Diálogo de Frase de Contraseña</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Ingresar la Frase de Contraseña</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nueva Frase de Contraseña</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repetí la nueva Frase de Contraseña</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>ModalOverlay</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    </context>
</TS>