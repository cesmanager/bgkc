<TS language="en_GB" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Right-click to edit address or label</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Create a new address</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;New</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copy the currently selected address to the system clipboard</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copy</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>C&amp;lose</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Delete the currently selected address from the list</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Export the data in the current tab to a file</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Export</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Delete</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Choose the address to send coins to</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Choose the address to receive coins with</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>C&amp;hoose</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Sending addresses</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Receiving addresses</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Copy Address</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Copy &amp;Label</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Edit</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Export Address List</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exporting Failed</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(no label)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Passphrase Dialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Enter passphrase</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>New passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repeat new passphrase</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Encrypt wallet</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP/Netmask</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Banned Until</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Sign &amp;message...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronising with network...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Overview</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Node</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Show general overview of wallet</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transactions</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Browse transaction history</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>E&amp;xit</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Quit application</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;About %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Show information about %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>About &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Show information about Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Options...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Modify configuration options for %1</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Encrypt Wallet...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Backup Wallet...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Change Passphrase...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Sending addresses...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Receiving addresses...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Open &amp;URI...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Reindexing blocks on disk...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin address</source>
        <translation>Send coins to a BGKC address</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Backup wallet to another location</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Change the passphrase used for wallet encryption</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Debug window</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Open debugging and diagnostic console</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verify message...</translation>
    </message>
    <message>
        <source>Bitcoin</source>
        <translation>BGKC</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Wallet</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Send</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Receive</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Show / Hide</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Show or hide the main Window</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Encrypt the private keys that belong to your wallet</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin addresses to prove you own them</source>
        <translation>Sign messages with your BGKC addresses to prove you own them</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin addresses</source>
        <translation>Verify messages to ensure they were signed with specified BGKC addresses</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Settings</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Help</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Tabs toolbar</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and bitcoin: URIs)</source>
        <translation>Request payments (generates QR codes and bgkc: URIs)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Show the list of used sending addresses and labels</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Show the list of used receiving addresses and labels</translation>
    </message>
    <message>
        <source>Open a bitcoin: URI or payment request</source>
        <translation>Open a bgkc: URI or payment request</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Command-line options</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Bitcoin network</source>
        <translation><numerusform>%n active connection to BGKC network</numerusform><numerusform>%n active connections to BGKC network</numerusform></translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>Indexing blocks on disk...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>Processing blocks on disk...</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation><numerusform>Processed %n block of transaction history.</numerusform><numerusform>Processed %n blocks of transaction history.</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 behind</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Last received block was generated %1 ago.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transactions after this will not yet be visible.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warning</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Up to date</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Bitcoin command-line options</source>
        <translation>Show the %1 help message to get a list with possible BGKC command-line options</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>%1 client</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Catching up...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Date: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Amount: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Type: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Label: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>Address: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Sent transaction</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Incoming transaction</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Coin Selection</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantity:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Amount:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Fee:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Dust:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>After Fee:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Change:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(un)select all</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Tree mode</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>List mode</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Amount</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Received with label</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Received with address</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Confirmations</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmed</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(no label)</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Edit Address</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Label</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>The label associated with this address list entry</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>The address associated with this address list entry. This can only be modified for sending addresses.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Address</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>A new data directory will be created.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>name</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Directory already exists. Add %1 if you intend to create a new directory here.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Path already exists, and is not a directory.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Cannot create data directory here.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>About %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Command-line options</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Usage:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>command-line options</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>UI Options:</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>Choose data directory on startup (default: %u)</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>Set language, for example "de_DE" (default: system locale)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Start minimised</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>Set SSL root certificates for payment request (default: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>Show splash screen on startup (default: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>Reset all settings changed in the GUI</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Welcome</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>Welcome to %1.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>As this is the first time the program is launched, you can choose where %1 will store its data.</translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Bitcoin block chain. At least %2GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>%1 will download and store a copy of the BGKC block chain. At least %2GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Use the default data directory</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Use a custom data directory:</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>Error: Specified data directory "%1" cannot be created.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation><numerusform>%n GB of free space available</numerusform><numerusform>%n GB of free space available</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation><numerusform>(of %n GB needed)</numerusform><numerusform>(of %n GB needed)</numerusform></translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Last block time</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Hide</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Open URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Open payment request from URI or file</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Select payment request file</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Main</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>Automatically start %1 after logging in to the system.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation>&amp;Start %1 on system login</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Size of &amp;database cache</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Number of script &amp;verification threads</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Accept connections from outside</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Allow incoming connections</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation>Minimise instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Third party transaction URLs</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Active command-line options that override above options:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Reset all client options to default.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Reset Options</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Network</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = auto, &lt;0 = leave that many cores free)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>W&amp;allet</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Expert</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Enable coin &amp;control features</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Spend unconfirmed change</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatically open the BGKC client port on the router. This only works when your router supports UPnP and it is enabled.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Map port using &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin network through a SOCKS5 proxy.</source>
        <translation>Connect to the BGKC network through a SOCKS5 proxy.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Connect through SOCKS5 proxy (default proxy):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port of the proxy (e.g. 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>Used for reaching peers via:</translation>
    </message>
    <message>
        <source>Shows, if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation>Shows, if the supplied default SOCKS5 proxy is used to reach peers via this network type.</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin network through a separate SOCKS5 proxy for Tor hidden services.</source>
        <translation>Connect to the BGKC network through a separate SOCKS5 proxy for Tor hidden services.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services:</source>
        <translation>Use separate SOCKS5 proxy to reach peers via Tor hidden services:</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Window</translation>
    </message>
    <message>
        <source>&amp;Hide the icon from the system tray.</source>
        <translation>&amp;Hide the icon from the system tray.</translation>
    </message>
    <message>
        <source>Hide tray icon</source>
        <translation>Hide tray icon</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Show on a tray icon after minimising the window.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimise to the tray instead of the task bar</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimise on close</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Display</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>User Interface &amp;language:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation>The user interface language can be set here. This setting will take effect after restarting %1.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unit to show amounts in:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Choose the default subdivision unit to show in the interface and when sending coins.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Whether to show coin control features or not.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancel</translation>
    </message>
    <message>
        <source>default</source>
        <translation>default</translation>
    </message>
    <message>
        <source>none</source>
        <translation>none</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Confirm options reset</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Client restart required to activate changes.</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>Client will be shut down. Do you want to proceed?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>This change would require a client restart.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>The supplied proxy address is invalid.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>The displayed information may be out of date. Your Wallet automatically synchronises with the BGKC Network after a connection is established, but this process has not been completed yet.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Watch-only:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Available:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Your current spendable balance</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Pending:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Immature:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Mined balance that has not yet matured</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Balances</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Your current total balance</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Your current balance in watch-only addresses</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Spendable:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Recent transactions</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Unconfirmed transactions to watch-only addresses</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>Mined balance in watch-only addresses that has not yet matured</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Current total balance in watch-only addresses</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>User Agent</translation>
    </message>
    <message>
        <source>Node/Service</source>
        <translation>Node/Service</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Amount</translation>
    </message>
    <message>
        <source>Enter a Bitcoin address (e.g. %1)</source>
        <translation>Enter a BGKC address (e.g. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 d</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <source>None</source>
        <translation>None</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 ms</translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 and %2</translation>
    </message>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Client version</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Debug window</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Using BerkeleyDB version</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation>Datadir</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Startup time</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Network</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Number of connections</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Block chain</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Current number of blocks</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Memory Pool</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Current number of transactions</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Memory usage</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Received</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Sent</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Peers</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Banned peers</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Select a peer to view detailed information.</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>Whitelisted</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Direction</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>Starting Block</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>Synced Headers</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>Synced Blocks</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>User Agent</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Decrease font size</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Increase font size</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Services</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Ban Score</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Connection Time</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Last Send</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Last Receive</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Ping Time</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>The duration of a currently outstanding ping.</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Ping Wait</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>Time Offset</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Last block time</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Open</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Console</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Network Traffic</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Clear</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totals</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>In:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Out:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debug log file</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Clear console</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;hour</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;day</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;week</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;year</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>Welcome to the %1 RPC console.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>(node id: %1)</source>
        <translation>(node id: %1)</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>via %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>never</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Inbound</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Outbound</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Yes</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Amount:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Message:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>R&amp;euse an existing receiving address (not recommended)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Bitcoin network.</source>
        <translation>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the BGKC network.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>An optional label to associate with the new receiving address.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>An optional amount to request. Leave this empty or zero to not request a specific amount.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Clear all fields of the form.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Clear</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Requested payments history</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Request payment</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Show the selected request (does the same as double clicking an entry)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Show</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Remove the selected entries from the list</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remove</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR Code</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Copy &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Copy &amp;Address</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Save Image...</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(no label)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Send Coins</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Coin Control Features</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Inputs...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>automatically selected</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Insufficient funds!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantity:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Amount:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Fee:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>After Fee:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Change:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Custom change address</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Transaction Fee:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Choose...</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>collapse fee-settings</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>per kilobyte</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then "per kilobyte" only pays 250 satoshis in fee, while "total at least" pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then "per kilobyte" only pays 250 satoshis in fee, while "total at least" pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Hide</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>total at least</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for bitcoin transactions than the network can process.</source>
        <translation>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for bgkc transactions than the network can process.</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(read the tooltip)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Recommended:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Custom:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation>(Smart fee not initialised yet. This usually takes a few blocks...)</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>fast</source>
        <translation>fast</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Send to multiple recipients at once</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Add &amp;Recipient</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Clear all fields of the form.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Dust:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Clear &amp;All</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Confirm the send action</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>S&amp;end</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(no label)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>A&amp;mount:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Pay &amp;To:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Choose previously used address</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>This is a normal payment.</translation>
    </message>
    <message>
        <source>The Bitcoin address to send the payment to</source>
        <translation>The BGKC address to send the payment to</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Paste address from clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Remove this entry</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less bitcoins than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation>The fee will be deducted from the amount being sent. The recipient will receive less bgkcs than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</translation>
    </message>
    <message>
        <source>S&amp;ubtract fee from amount</source>
        <translation>S&amp;ubtract fee from amount</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Message:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>This is an unauthenticated payment request.</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>This is an authenticated payment request.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Enter a label for this address to add it to the list of used addresses</translation>
    </message>
    <message>
        <source>A message that was attached to the bitcoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin network.</source>
        <translation>A message that was attached to the bgkc: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the BGKC network.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Pay To:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>%1 is shutting down...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Do not shut down the computer until this window disappears.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signatures - Sign / Verify a Message</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Sign Message</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive bitcoins sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>You can sign messages/agreements with your addresses to prove you can receive bgkcs sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</translation>
    </message>
    <message>
        <source>The Bitcoin address to sign the message with</source>
        <translation>The BGKC address to sign the message with</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Choose previously used address</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Paste address from clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Enter the message you want to sign here</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Signature</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Copy the current signature to the system clipboard</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin address</source>
        <translation>Sign the message to prove you own this BGKC address</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Sign &amp;Message</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Reset all sign message fields</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Clear &amp;All</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verify Message</translation>
    </message>
    <message>
        <source>Enter the receiver's address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation>Enter the receiver's address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</translation>
    </message>
    <message>
        <source>The Bitcoin address the message was signed with</source>
        <translation>The BGKC address the message was signed with</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin address</source>
        <translation>Verify the message to ensure it was signed with the specified BGKC address</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Verify &amp;Message</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Reset all verify message fields</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>This pane shows a detailed description of the transaction</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(no label)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exporting Failed</translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>Unit to show amounts in. Click to select another unit.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Options:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Specify data directory</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Connect to a node to retrieve peer addresses, and disconnect</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Specify your own public address</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accept command line and JSON-RPC commands</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied or if &lt;category&gt; = 1, output all debugging information.</source>
        <translation>If &lt;category&gt; is not supplied or if &lt;category&gt; = 1, output all debugging information.</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation>Prune configured below the minimum of %d MiB.  Please use a higher number.</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</translation>
    </message>
    <message>
        <source>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</source>
        <translation>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Error: A fatal internal error occurred, see debug.log for details</translation>
    </message>
    <message>
        <source>Fee (in %s/kB) to add to transactions you send (default: %s)</source>
        <translation>Fee (in %s/kB) to add to transactions you send (default: %s)</translation>
    </message>
    <message>
        <source>Pruning blockstore...</source>
        <translation>Pruning blockstore...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Run in the background as a daemon and accept commands</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>Unable to start HTTP server. See debug log for details.</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>BGKC</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>The %s developers</translation>
    </message>
    <message>
        <source>A fee rate (in %s/kB) that will be used when fee estimation has insufficient data (default: %s)</source>
        <translation>A fee rate (in %s/kB) that will be used when fee estimation has insufficient data (default: %s)</translation>
    </message>
    <message>
        <source>Accept relayed transactions received from whitelisted peers even when not relaying transactions (default: %d)</source>
        <translation>Accept relayed transactions received from whitelisted peers even when not relaying transactions (default: %d)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Bind to given address and always listen on it. Use [host]:port notation for IPv6</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. %s is probably already running.</source>
        <translation>Cannot obtain a lock on data directory %s. %s is probably already running.</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</translation>
    </message>
    <message>
        <source>Error loading %s: You can't enable HD on a already existing non-HD wallet</source>
        <translation>Error loading %s: You can't enable HD on a already existing non-HD wallet</translation>
    </message>
    <message>
        <source>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</translation>
    </message>
    <message>
        <source>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</source>
        <translation>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</translation>
    </message>
    <message>
        <source>Maximum total fees (in %s) to use in a single wallet transaction or raw transaction; setting this too low may abort large transactions (default: %s)</source>
        <translation>Maximum total fees (in %s) to use in a single wallet transaction or raw transaction; setting this too low may abort large transactions (default: %s)</translation>
    </message>
    <message>
        <source>Please check that your computer's date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation>Please check that your computer's date and time are correct! If your clock is wrong, %s will not work properly.</translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation>Please contribute if you find %s useful. Visit %s for further information about the software.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</translation>
    </message>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer's date and time being set incorrectly. Only rebuild the block database if you are sure that your computer's date and time are correct</source>
        <translation>The block database contains a block which appears to be from the future. This may be due to your computer's date and time being set incorrectly. Only rebuild the block database if you are sure that your computer's date and time are correct</translation>
    </message>
    <message>
        <source>Unable to rewind the database to a pre-fork state. You will need to redownload the blockchain</source>
        <translation>Unable to rewind the database to a pre-fork state. You will need to re-download the blockchain</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening and no -proxy)</source>
        <translation>Use UPnP to map the listening port (default: 1 when listening and no -proxy)</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex-chainstate to change -txindex</source>
        <translation>You need to rebuild the database using -reindex-chainstate to change -txindex</translation>
    </message>
    <message>
        <source>%s corrupt, salvage failed</source>
        <translation>%s corrupt, salvage failed</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation>-maxmempool must be at least %d MB</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; can be:</translation>
    </message>
    <message>
        <source>Append comment to the user agent string</source>
        <translation>Append comment to the user agent string</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet on startup</source>
        <translation>Attempt to recover private keys from a corrupt wallet on startup</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Block creation options:</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: '%s'</source>
        <translation>Cannot resolve -%s address: '%s'</translation>
    </message>
    <message>
        <source>Change index out of range</source>
        <translation>Change index out of range</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Connection options:</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>Copyright (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Corrupted block database detected</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Debugging/Testing options:</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Do not load the wallet and disable wallet RPC calls</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Do you want to rebuild the block database now?</translation>
    </message>
    <message>
        <source>Enable publish hash block in &lt;address&gt;</source>
        <translation>Enable publish hash block in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish hash transaction in &lt;address&gt;</source>
        <translation>Enable publish hash transaction in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw block in &lt;address&gt;</source>
        <translation>Enable publish raw block in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw transaction in &lt;address&gt;</source>
        <translation>Enable publish raw transaction in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable transaction replacement in the memory pool (default: %u)</source>
        <translation>Enable transaction replacement in the memory pool (default: %u)</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Error initialising block database</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Error initialising wallet database environment %s!</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>Error loading %s</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>Error loading %s: Wallet corrupted</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>Error loading %s: Wallet requires newer version of %s</translation>
    </message>
    <message>
        <source>Error loading %s: You can't disable HD on a already existing HD wallet</source>
        <translation>Error loading %s: You can't disable HD on a already existing HD wallet</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Error loading block database</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Error opening block database</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Error: Disk space is low!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Failed to listen on any port. Use -listen=0 if you want this.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importing...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Incorrect or no genesis block found. Wrong datadir for network?</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. %s is shutting down.</source>
        <translation>Initialisation sanity check failed. %s is shutting down.</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>Invalid -onion address: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: '%s'</source>
        <translation>Invalid amount for -%s=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -fallbackfee=&lt;amount&gt;: '%s'</source>
        <translation>Invalid amount for -fallbackfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Keep the transaction memory pool below &lt;n&gt; megabytes (default: %u)</source>
        <translation>Keep the transaction memory pool below &lt;n&gt; megabytes (default: %u)</translation>
    </message>
    <message>
        <source>Loading banlist...</source>
        <translation>Loading banlist...</translation>
    </message>
    <message>
        <source>Location of the auth cookie (default: data dir)</source>
        <translation>Location of the auth cookie (default: data dir)</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Not enough file descriptors available.</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</translation>
    </message>
    <message>
        <source>Print this help message and exit</source>
        <translation>Print this help message and exit</translation>
    </message>
    <message>
        <source>Print version and exit</source>
        <translation>Print version and exit</translation>
    </message>
    <message>
        <source>Prune cannot be configured with a negative value.</source>
        <translation>Prune cannot be configured with a negative value.</translation>
    </message>
    <message>
        <source>Prune mode is incompatible with -txindex.</source>
        <translation>Prune mode is incompatible with -txindex.</translation>
    </message>
    <message>
        <source>Rebuild chain state and block index from the blk*.dat files on disk</source>
        <translation>Rebuild chain state and block index from the blk*.dat files on disk</translation>
    </message>
    <message>
        <source>Rebuild chain state from the currently indexed blocks</source>
        <translation>Rebuild chain state from the currently indexed blocks</translation>
    </message>
    <message>
        <source>Rewinding blocks...</source>
        <translation>Rewinding blocks...</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Set database cache size in megabytes (%d to %d, default: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Set maximum block size in bytes (default: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Specify wallet file (within data directory)</translation>
    </message>
    <message>
        <source>The source code is available from %s.</source>
        <translation>The source code is available from %s.</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation>Unable to bind to %s on this computer. %s is probably already running.</translation>
    </message>
    <message>
        <source>Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>Unsupported argument -benchmark ignored, use -debug=bench.</translation>
    </message>
    <message>
        <source>Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Unsupported argument -debugnet ignored, use -debug=net.</translation>
    </message>
    <message>
        <source>Unsupported argument -tor found, use -onion.</source>
        <translation>Unsupported argument -tor found, use -onion.</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>Use UPnP to map the listening port (default: %u)</translation>
    </message>
    <message>
        <source>User Agent comment (%s) contains unsafe characters.</source>
        <translation>User Agent comment (%s) contains unsafe characters.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verifying blocks...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verifying wallet...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Wallet %s resides outside data directory %s</translation>
    </message>
    <message>
        <source>Wallet debugging/testing options:</source>
        <translation>Wallet debugging/testing options:</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>Wallet needed to be rewritten: restart %s to complete</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Wallet options:</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</translation>
    </message>
    <message>
        <source>Discover own IP addresses (default: 1 when listening and no -externalip or -proxy)</source>
        <translation>Discover own IP addresses (default: 1 when listening and no -externalip or -proxy)</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Error: Listening for incoming connections failed (listen returned error %s)</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for relaying, mining and transaction creation (default: %s)</source>
        <translation>Fees (in %s/kB) smaller than this are considered zero fee for relaying, mining and transaction creation (default: %s)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: '%s' (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>Invalid amount for -maxtxfee=&lt;amount&gt;: '%s' (must be at least the minrelay fee of %s to prevent stuck transactions)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>Maximum size of data in data carrier transactions we relay and mine (default: %u)</translation>
    </message>
    <message>
        <source>Randomize credentials for every proxy connection. This enables Tor stream isolation (default: %u)</source>
        <translation>Randomise credentials for every proxy connection. This enables Tor stream isolation (default: %u)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>The transaction amount is too small to send after the fee has been deducted</translation>
    </message>
    <message>
        <source>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</source>
        <translation>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</translation>
    </message>
    <message>
        <source>(default: %u)</source>
        <translation>(default: %u)</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>Accept public REST requests (default: %u)</translation>
    </message>
    <message>
        <source>Automatically create Tor hidden service (default: %d)</source>
        <translation>Automatically create Tor hidden service (default: %d)</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Connect through SOCKS5 proxy</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Error reading from database, shutting down.</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file on startup</source>
        <translation>Imports blocks from external blk000??.dat file on startup</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s' (must be at least %s)</source>
        <translation>Invalid amount for -paytxfee=&lt;amount&gt;: '%s' (must be at least %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: '%s'</source>
        <translation>Invalid netmask specified in -whitelist: '%s'</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: '%s'</source>
        <translation>Need to specify a port with -whitebind: '%s'</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Node relay options:</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>RPC server options:</translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation>Reducing -maxconnections from %d to %d, because of system limitations.</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions on startup</source>
        <translation>Rescan the block chain for missing wallet transactions on startup</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Send trace/debug info to console instead of debug.log file</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>Send transactions as zero-fee transactions if possible (default: %u)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Show all debugging options (usage: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Shrink debug.log file on client startup (default: 1 when no -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Signing transaction failed</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation>The transaction amount is too small to pay the fee</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>This is experimental software.</translation>
    </message>
    <message>
        <source>Tor control port password (default: empty)</source>
        <translation>Tor control port password (default: empty)</translation>
    </message>
    <message>
        <source>Tor control port to use if onion listening enabled (default: %s)</source>
        <translation>Tor control port to use if onion listening enabled (default: %s)</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transaction amount too small</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Transaction too large for fee policy</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transaction too large</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Unable to bind to %s on this computer (bind returned error %s)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format on startup</source>
        <translation>Upgrade wallet to latest format on startup</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Username for JSON-RPC connections</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warning</translation>
    </message>
    <message>
        <source>Warning: unknown new rules activated (versionbit %i)</source>
        <translation>Warning: unknown new rules activated (versionbit %i)</translation>
    </message>
    <message>
        <source>Whether to operate in a blocks only mode (default: %u)</source>
        <translation>Whether to operate in a blocks only mode (default: %u)</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Zapping all transactions from wallet...</translation>
    </message>
    <message>
        <source>ZeroMQ notification options:</source>
        <translation>ZeroMQ notification options:</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Password for JSON-RPC connections</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Execute command when the best block changes (%s in cmd is replaced by block hash)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Allow DNS lookups for -addnode, -seednode and -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Loading addresses...</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</translation>
    </message>
    <message>
        <source>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</translation>
    </message>
    <message>
        <source>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</source>
        <translation>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</translation>
    </message>
    <message>
        <source>Equivalent bytes per sigop in transactions for relay and mining (default: %u)</source>
        <translation>Equivalent bytes per sigop in transactions for relay and mining (default: %u)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>Fees (in %s/kB) smaller than this are considered zero fee for transaction creation (default: %s)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>How thorough the block verification of -checkblocks is (0-4, default: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</translation>
    </message>
    <message>
        <source>Support filtering of blocks and transaction with bloom filters (default: %u)</source>
        <translation>Support filtering of blocks and transaction with bloom filters (default: %u)</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</translation>
    </message>
    <message>
        <source>Tries to keep outbound traffic under the given target (in MiB per 24h), 0 = no limit (default: %d)</source>
        <translation>Tries to keep outbound traffic under the given target (in MiB per 24h), 0 = no limit (default: %d)</translation>
    </message>
    <message>
        <source>Unsupported argument -socks found. Setting SOCKS version isn't possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>Unsupported argument -socks found. Setting SOCKS version isn't possible anymore, only SOCKS5 proxies are supported.</translation>
    </message>
    <message>
        <source>Unsupported argument -whitelistalwaysrelay ignored, use -whitelistrelay and/or -whitelistforcerelay.</source>
        <translation>Unsupported argument -whitelistalwaysrelay ignored, use -whitelistrelay and/or -whitelistforcerelay.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</translation>
    </message>
    <message>
        <source>Warning: Unknown block versions being mined! It's possible unknown rules are in effect</source>
        <translation>Warning: Unknown block versions being mined! It's possible unknown rules are in effect</translation>
    </message>
    <message>
        <source>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(default: %s)</translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>Always query for peer addresses via DNS lookup (default: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>How many blocks to check at startup (default: %u, 0 = all)</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>Include IP addresses in debug output (default: %u)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Invalid -proxy address: '%s'</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>Maintain at most &lt;n&gt; connections to peers (default: %u)</translation>
    </message>
    <message>
        <source>Make the wallet broadcast transactions</source>
        <translation>Make the wallet broadcast transactions</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>Prepend debug output with timestamp (default: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>Relay and mine data carrier transactions (default: %u)</translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>Relay non-P2SH multisig (default: %u)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>Set key pool size to &lt;n&gt; (default: %u)</translation>
    </message>
    <message>
        <source>Set maximum BIP141 block weight (default: %d)</source>
        <translation>Set maximum BIP141 block weight (default: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>Set the number of threads to service RPC calls (default: %d)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Specify configuration file (default: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Specify connection timeout in milliseconds (minimum: 1, default: %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>Specify pid file (default: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>Spend unconfirmed change when sending transactions (default: %u)</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>Threshold for disconnecting misbehaving peers (default: %u)</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>Unknown network specified in -onlynet: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Insufficient funds</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Loading block index...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Add a node to connect to and attempt to keep the connection open</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Loading wallet...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Cannot downgrade wallet</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Cannot write default address</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Rescanning...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Done loading</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
</context>
</TS>